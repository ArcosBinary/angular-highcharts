/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="up2date-angular-highcharts" />
export * from './public-api';
